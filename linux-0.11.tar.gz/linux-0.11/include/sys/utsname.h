#ifndef _SYS_UTSNAME_H
#define _SYS_UTSNAME_H

#include <sys/types.h>

// utsname 结构含有一些字符串字段， 用于保存系统的名称。其中包含 5 个字段，分别是：
// 当前操作系统的名称、网络节点名称（主机名）、当前操作系统发行级别、操作系统版本
// 号以及系统运行的硬件类型名称。该结构定义在 include/sys/utsname.h 文件中。 这里
// 内核使用 include/linux/config.h 文件中的常数符号设置了它们的默认值。它们分别为
// “ Linux”，“ (none)”，“ 0”，“ 0.12”，“ i386”。

struct utsname {
	char sysname[9];
	char nodename[9];
	char release[9];
	char version[9];
	char machine[9];
};

extern int uname(struct utsname *utsbuf);

#endif
