#ifndef _SYS_H
#define _SYS_H

#include <sys/stat.h>
#include <sys/times.h>
#include <sys/utsname.h>
#include <utime.h>
/* 
 * 功能：系统设置函数。
 *	本函数主要功能是读取 CMOS 硬盘参数表信息，用于设置硬盘分区结构
 *	hd， 并尝试加载 RAM 虚拟盘和根文件系统.
 *	该函数只在初始化时被调用一次。用静态变量 callable 作为可调用标志。
 *
 * @参数 BIOS：
 *	指向硬盘参数表结构的指针.
 *
 *	该硬盘参数表结构包含 2 个硬盘参数表的内容（共 32 字节），
 *	是从内存 0x90080 处复制而来。
 *	0x90080 处的硬盘参数表是由 setup.s 程序利用 ROM BIOS 功能取得。
 *	硬盘参数表信息请参见
 *
 * @返回值
 *	-成功 (0).
 *	-失败 (-1).
 */
int sys_setup(void *BIOS);

/* 
 * 功能：系统调用 exit()。终止进程。
 *
 * @参数 error_code：
 *	用户程序提供的退出状态信息，只有低字节有效。
 *	把 error_code 左移 8比特是 wait() 或 waitpid()函数的要求。
 *	低字节中将用来保存 wait()的状态信息。
 *	如果进程处于暂停状态（ TASK_STOPPED） ，那么其低字节就等于 0x7f。
 *	wait() 或 waitpid() 利用这些宏就可以取得子进程的退出状态码或子
 *	进程终止的原因（信号）。
 *
 * @返回值
 *	- ().
 */
int sys_exit(int error_code);

extern int sys_fork();

/**
 *  读文件系统调用.
 *
 * @param fd
 *   文件句柄.
 * @param buf
 *   缓冲区.
 * @param count
 *   欲读字节数.
 * @return
 *   Zero if successful. -EINVAL otherwise.
 */
int sys_read(unsigned int fd, char *buf, int count);

int sys_write(unsigned int fd, char *buf, int count);

/**
 *  打开（或创建）文件系统调用.
 *
 * @param filename
 *   文件名.
 * @param flag
 *   打开文件标志，它可取值： O_RDONLY（只读）、 O_WRONLY（只写）或
 *   O_RDWR（读写），以及 O_CREAT（创建）、 O_EXCL（被创建文件必须不存在）、
 *   O_APPEND（在文件尾添加数据）等其他一些标志的组合.
 * @param mode
 *   如果本调用创建了一个新文件，则 mode 就用于指定文件的许可属性。
 *   这些属性有 S_IRWXU（文件宿主具有读、写和执行权限）、 
 *   S_IRUSR（用户具有读文件权限）、 S_IRWXG（组成员具有读、写和执行权限）等等。
 *   对于新创建的文件，这些属性只应用于将来对文件的访问。
 * @return
 *   如果调用操作成功，则返回文件句柄 (文件描述符)，否则返回出错码.
 */
int sys_open(const char *filename, int flag, int mode);

int sys_close(unsigned int fd);

int sys_waitpid(pid_t pid, unsigned long *stat_addr, int options);

int sys_creat(const char *pathname, int mode);

int sys_link(const char *oldname, const char *newname);

int sys_unlink(const char *name);

extern int sys_execve();

int sys_chdir(const char *filename);

int sys_time(long *tloc);

int sys_mknod(const char *filename, int mode, int dev);

int sys_chmod(const char *filename, int mode);

int sys_chown(const char *filename, int uid, int gid);

extern int sys_break();

int sys_stat(char *filename, struct stat *statbuf);

int sys_lseek(unsigned int fd, off_t offset, int origin);

int sys_getpid(void);

int sys_mount(char *dev_name, char *dir_name, int rw_flag);

int sys_umount(char *dev_name);

int sys_setuid(int uid);
int sys_getuid(void);
int sys_stime(long *tptr);
extern int sys_ptrace();
int sys_alarm(long seconds);
int sys_fstat(unsigned int fd, struct stat *statbuf);
int sys_pause(void);
int sys_utime(char *filename, struct utimbuf *times);
extern int sys_stty();
extern int sys_gtty();
int sys_access(const char *filename, int mode);
int sys_nice(long increment);
extern int sys_ftime();
int sys_sync(void);
int sys_kill(int pid, int sig);
extern int sys_rename();
int sys_mkdir(const char *pathname, int mode);
int sys_rmdir(const char *name);
int sys_dup(unsigned int fildes);
int sys_pipe(unsigned long *fildes);
int sys_times(struct tms *tbuf);
extern int sys_prof();
int sys_brk(unsigned long end_data_seg);
int sys_setgid(int gid);
int sys_getgid(void);
extern int sys_signal();
int sys_signal(int signum, long handler, long restorer);
int sys_geteuid(void);
int sys_getegid(void);
extern int sys_acct();
extern int sys_phys();
extern int sys_lock();
int sys_ioctl(unsigned int fd, unsigned int cmd, unsigned long arg);
int sys_fcntl(unsigned int fd, unsigned int cmd, unsigned long arg);
extern int sys_mpx();
int sys_setpgid(int pid, int pgid);
extern int sys_ulimit();
int sys_uname(struct utsname *name);
int sys_umask(int mask);
int sys_chroot(const char *filename);
int sys_ustat(int dev, struct ustat *ubuf);
int sys_dup2(unsigned int oldfd, unsigned int newfd);
int sys_getppid(void);
int sys_getpgrp(void);
int sys_setsid(void);
int sys_sigaction(int signum, const struct sigaction *action,
		  struct sigaction *oldaction);
int sys_sgetmask(void);
int sys_ssetmask(int newmask);
int sys_setreuid(int ruid, int euid);
int sys_setregid(int rgid, int egid);

fn_ptr sys_call_table[] = { sys_setup, sys_exit, sys_fork, sys_read,
	sys_write, sys_open, sys_close, sys_waitpid, sys_creat, sys_link,
	sys_unlink, sys_execve, sys_chdir, sys_time, sys_mknod, sys_chmod,
	sys_chown, sys_break, sys_stat, sys_lseek, sys_getpid, sys_mount,
	sys_umount, sys_setuid, sys_getuid, sys_stime, sys_ptrace, sys_alarm,
	sys_fstat, sys_pause, sys_utime, sys_stty, sys_gtty, sys_access,
	sys_nice, sys_ftime, sys_sync, sys_kill, sys_rename, sys_mkdir,
	sys_rmdir, sys_dup, sys_pipe, sys_times, sys_prof, sys_brk, sys_setgid,
	sys_getgid, sys_signal, sys_geteuid, sys_getegid, sys_acct, sys_phys,
	sys_lock, sys_ioctl, sys_fcntl, sys_mpx, sys_setpgid, sys_ulimit,
	sys_uname, sys_umask, sys_chroot, sys_ustat, sys_dup2, sys_getppid,
	sys_getpgrp, sys_setsid, sys_sigaction, sys_sgetmask, sys_ssetmask,
	sys_setreuid, sys_setregid
};
#endif
