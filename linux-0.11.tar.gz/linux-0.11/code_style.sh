#!/bin/sh
#Lindent=~/gitlab/x86-kernel/scripts/Lindent
#Object=~/gitlab/haoos/linux-0.11
#function changeName() {
#	echo $1
#	#这个方法里面可以对该文件进行操作
#	#mv $1  test.txt
#	#rm -r $1
#	rm *~
#}
function travFolder() {
	echo $1
	flist=`ls $1`
	cd $1
	#echo $flist
	for f in $flist
	do
	if test -d $f
	then
	echo "dir:$f"
	travFolder $f
	else
	echo "file:$f"
	#changeName $f
	rm *~
	fi
	done
	cd ../
}
travFolder $1


