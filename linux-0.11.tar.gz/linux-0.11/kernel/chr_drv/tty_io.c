/*
 *  linux/kernel/tty_io.c
 *
 *  (C) 1991  Linus Torvalds
 */

/*
 * 'tty_io.c' gives an orthogonal feeling to tty's, be they consoles
 * or rs-channels. It also implements echoing, cooked mode etc.
 *
 * Kill-line thanks to John T Kohl.
 */

/*
* 'tty_io.c'给 tty 终端一种非相关的感觉，不管它们是控制台还是串行终端。
* 该程序同样实现了回显、规范(熟)模式等。
*
* Kill-line，谢谢 John T Kohl。他同时还纠正了当 VMIN = VTIME = 0 时的问题。
*/

#include <ctype.h>		// 字符类型头文件。定义了一些有关字符类型判断和转换的宏。
#include <errno.h>		// 错误号头文件。包含系统中各种出错号。
#include <signal.h>		// 信号头文件。定义信号符号常量，信号结构及其操作函数原型。

// 给出定时警告（ alarm）信号在信号位图中对应的比特屏蔽位。
#define ALRMMASK (1 << (SIGALRM - 1))
#define KILLMASK (1 << (SIGKILL - 1))
#define INTMASK (1 << (SIGINT - 1))
#define QUITMASK (1 << (SIGQUIT - 1))
#define TSTPMASK (1 << (SIGTSTP - 1))

#include <linux/sched.h>
#include <linux/tty.h>
#include <asm/segment.h>
#include <asm/system.h>

// 获取 termios 结构中三个模式标志集之一，
// 或者用于判断一个标志集中是否有置位的标志。
#define _L_FLAG(tty,f)	((tty)->termios.c_lflag & f)	// 本地模式标志。
#define _I_FLAG(tty,f)	((tty)->termios.c_iflag & f)	// 输入模式标志。
#define _O_FLAG(tty,f)	((tty)->termios.c_oflag & f)	// 输出模式标志。

// 取 termios 结构终端特殊（本地）模式标志集中的一个标志。

#define L_CANON(tty)	_L_FLAG((tty), ICANON)	// 取规范模式标志。
#define L_ISIG(tty)	_L_FLAG((tty), ISIG)	// 取信号标志。
#define L_ECHO(tty)	_L_FLAG((tty), ECHO)	// 取回显字符标志。
#define L_ECHOE(tty)	_L_FLAG((tty), ECHOE)	// 规范模式时取回显擦出标志。
#define L_ECHOK(tty)	_L_FLAG((tty), ECHOK)	// 规范模式时取 KILL 擦除当前行标志。
#define L_ECHOCTL(tty)	_L_FLAG((tty), ECHOCTL)	// 取回显控制字符标志。
#define L_ECHOKE(tty)	_L_FLAG((tty), ECHOKE)	// 规范模式时取 KILL 擦除行并回显标志。

// 取 termios 结构输入模式标志集中的一个标志。
#define I_UCLC(tty)	_I_FLAG((tty),IUCLC)	// 取大写到小写转换标志。
#define I_NLCR(tty)	_I_FLAG((tty),INLCR)	// 取换行符 NL 转回车符 CR 标志。
#define I_CRNL(tty)	_I_FLAG((tty),ICRNL)	// 取回车符 CR 转换行符 NL 标志。
#define I_NOCR(tty)	_I_FLAG((tty),IGNCR)	// 取忽略回车符 CR 标志。

// 取 termios 结构输出模式标志集中的一个标志。
#define O_POST(tty)	_O_FLAG((tty),OPOST)	// 取执行输出处理标志。
#define O_NLCR(tty)	_O_FLAG((tty),ONLCR)	// 取换行符 NL 转回车换行符 CR-NL 标志。
#define O_CRNL(tty)	_O_FLAG((tty),OCRNL)	// 取回车符 CR 转换行符 NL 标志。
#define O_NLRET(tty)	_O_FLAG((tty),ONLRET)	// 取换行符 NL 执行回车功能的标志。
#define O_LCUC(tty)	_O_FLAG((tty),OLCUC)	// 取小写转大写字符标志。

struct tty_struct tty_table[] = {
	{
	 { ICRNL,		/* change incoming CR to NL */
	  OPOST | ONLCR,	/* change outgoing NL to CRNL */
	  0,
	  ISIG | ICANON | ECHO | ECHOCTL | ECHOKE,
	  0,			/* console termio */
	  INIT_C_CC},
	 0,			/* initial pgrp */
	 0,			/* initial stopped */
	 con_write,
	 { 0, 0, 0, 0, ""},	/* console read-queue */
	 { 0, 0, 0, 0, ""},	/* console write-queue */
	 { 0, 0, 0, 0, ""}	/* console secondary queue */
	  }, {
	      { 0,		/* no translation */
	       0,		/* no translation */
	       B2400 | CS8,
	       0,
	       0,
	       INIT_C_CC},
	      0,
	      0,
	      rs_write,
	      { 0x3f8, 0, 0, 0, ""},	/* rs 1 */
	      { 0x3f8, 0, 0, 0, ""},
	      { 0, 0, 0, 0, ""}
	       }, {
		   { 0,		/* no translation */
		    0,		/* no translation */
		    B2400 | CS8,
		    0,
		    0,
		    INIT_C_CC},
		   0,
		   0,
		   rs_write,
		   { 0x2f8, 0, 0, 0, ""},	/* rs 2 */
		   { 0x2f8, 0, 0, 0, ""},
		   { 0, 0, 0, 0, ""}
		    }
};

/*
 * these are the tables used by the machine code handlers.
 * you can implement pseudo-tty's or something by changing
 * them. Currently not done.
 */

/*
* 下面是汇编程序中使用的缓冲队列结构地址表。通过修改这个表，
* 你可以实现虚拟控制台。
*/
// tty 读写缓冲队列结构地址表。供 rs_io.s 程序使用，
// 用于取得读写缓冲队列结构的地址。
struct tty_queue *table_list[] = {
	&tty_table[0].read_q, &tty_table[0].write_q,	// 前台控制台读、写队列结构地址。
	&tty_table[1].read_q, &tty_table[1].write_q,	// 串行终端 1 读、写队列结构地址。
	&tty_table[2].read_q, &tty_table[2].write_q	// 串行终端 2 读、写队列结构地址。
};

//// tty 终端初始化函数。
// 初始化所有终端缓冲队列，初始化串口终端和控制台终端。
void tty_init(void)
{
	rs_init();
	con_init();
}

void tty_intr(struct tty_struct *tty, int mask)
{
	int i;

	if (tty->pgrp <= 0)
		return;
	for (i = 0; i < NR_TASKS; i++)
		if (task[i] && task[i]->pgrp == tty->pgrp)
			task[i]->signal |= mask;
}

static void sleep_if_empty(struct tty_queue *queue)
{
	cli();
	while (!current->signal && EMPTY(*queue))
		interruptible_sleep_on(&queue->proc_list);
	sti();
}

static void sleep_if_full(struct tty_queue *queue)
{
	if (!FULL(*queue))
		return;
	cli();
	while (!current->signal && LEFT(*queue) < 128)
		interruptible_sleep_on(&queue->proc_list);
	sti();
}

void wait_for_keypress(void)
{
	sleep_if_empty(&tty_table[0].secondary);
}

//// 复制并转换成规范模式字符序列。
// 根据终端 termios 结构中设置的各种标志，将指定 tty 终端读队列缓冲区中的字符复
// 制并转换成规范模式（熟模式）字符并存放在辅助队列（规范模式队列）中。
// 参数： tty - 指定终端的 tty 结构指针。
void copy_to_cooked(struct tty_struct *tty)
{
	signed char c;

	while (!EMPTY(tty->read_q) && !FULL(tty->secondary)) {
		GETCH(tty->read_q, c);
		// 如果大写转小写输入标志 UCLC 置位，则将该字符转换为小写字符。
		if (c == 13)
			if (I_CRNL(tty))
				c = 10;
			else if (I_NOCR(tty))
				continue;
			else;
		else if (c == 10 && I_NLCR(tty))
			c = 13;
		if (I_UCLC(tty))
			c = tolower(c);
// 如果本地模式标志集中规范模式标志 CANON 已置位，则使用以下方式对读取的字符进行
// 处理。
// 首先，如果该字符是键盘终止控制字符 KILL (^U)，则对已输入的当前字符行执行删除
// 处理。
// 删除一行字符的过程是： 如果 tty 辅助队列不空，并且辅助队列中取出的最后一个字
// 符不是换行符 NL（ 10），并且该字符不是文件结束字符（ ^D） 或该文件结束字符不
// 等于_POSIX_VDISABLE，则循环地对该行上所有其它字符进行删除处理。删除过程中，
// 若本地回显标志 ECHO 是置位的，那么还需往写队列加入擦除控制字符 ERASE（ ^H）。
// 若字符是控制字符（值 < 32），使用两字节表示（例如^V），则须多放入一个擦除字符
// ERASE。然后调用 tty 写函数把写队列中的所有字符输出到终端设备。最后将 tty 辅助
// 队列头指针后退 1 字节。
		if (L_CANON(tty)) {
			if (c == KILL_CHAR(tty)) {
				/* deal with killing the input line */
				while (!(EMPTY(tty->secondary) ||
					 (c = LAST(tty->secondary)) == 10 ||
					 c == EOF_CHAR(tty))) {
					if (L_ECHO(tty)) {
						if (c < 32)
							PUTCH(127,
							      tty->write_q);
						PUTCH(127, tty->write_q);
						tty->write(tty);
					}
					DEC(tty->secondary.head);
				}
				continue;
			}
			if (c == ERASE_CHAR(tty)) {
				if (EMPTY(tty->secondary) ||
				    (c = LAST(tty->secondary)) == 10 ||
				    c == EOF_CHAR(tty))
					continue;
				if (L_ECHO(tty)) {	// 若本地回显标志置位。
					if (c < 32)	// 控制字符要删 2 字节。
						PUTCH(127, tty->write_q);
					PUTCH(127, tty->write_q);
					tty->write(tty);
				}
				DEC(tty->secondary.head);
				continue;	// 继续读取读队列中字符进行处理。
			}
			if (c == STOP_CHAR(tty)) {
				tty->stopped = 1;
				continue;
			}
			if (c == START_CHAR(tty)) {
				tty->stopped = 0;
				continue;
			}
		}
// 若输入模式标志集中 ISIG 标志置位，表示终端键盘可以产生信号，则在收到控制字符
// INTR、QUIT、 SUSP 或 DSUSP 时，需要为进程产生相应的信号。 如果该字符是键盘中
// 断符（ ^C），则向当前进程之进程组中所有进程发送键盘中断信号 SIGINT，并继续处
// 理下一字符。 如果该字符是退出符（ ^\），则向当前进程之进程组中所有进程发送键
// 盘退出信号 SIGQUIT，并继续处理下一字符。如果字符是暂停符（ ^Z），则向当前进
// 程发送暂停信号 SIGTSTP。同样，若定义了_POSIX_VDISABLE（ \0），那么在对字符处
// 理过程中，若字符代码值等于_POSIX_VDISABLE的值时，表示禁止使用相应特殊控制字符
// 的功能。以下不再啰嗦了 :-)
		if (L_ISIG(tty)) {
			if (c == INTR_CHAR(tty)) {
				tty_intr(tty, INTMASK);
				continue;
			}
			if (c == QUIT_CHAR(tty)) {
				tty_intr(tty, QUITMASK);
				continue;
			}
		}
// 如果该字符是换行符 NL（ 10），或者是文件结束符 EOF（ 4， ^D），表示一行字符
// 已处理完，则把辅助缓冲队列中当前含有行数值 secondary.data 增 1。如果在函数
// tty_read()中取走一行字符，该值即会被减 1，参见 315 行。
		if (c == 10 || c == EOF_CHAR(tty))
			tty->secondary.data++;
// 如果本地模式标志集中回显标志 ECHO 在置位状态，那么，如果字符是换行符
// NL（ 10），则还需将换行符 NL（ 10）和回车符 CR（ 13）放入 tty 写队列缓冲区中；
// 如果字符是控制字符（值<32）并且回显控制字符标志 ECHOCTL 置位，则将字符'^'和
// 字符 c+64 放入 tty 写队列中（也即会显示^C、 ^H 等)；否则将该字符直接放入
// tty 写缓冲队列中。最后调用该 tty 写操作函数。
		if (L_ECHO(tty)) {
			if (c == 10) {
				PUTCH(10, tty->write_q);
				PUTCH(13, tty->write_q);
			} else if (c < 32) {
				if (L_ECHOCTL(tty)) {
					PUTCH('^', tty->write_q);
					PUTCH(c + 64, tty->write_q);
				}
			} else
				PUTCH(c, tty->write_q);
			tty->write(tty);
		}
// 每一次循环末将处理过的字符放入辅助队列中。
// 最后在退出循环体后唤醒等待该辅助缓冲队列的进程（如果有的话）。
		PUTCH(c, tty->secondary);
	}
	wake_up(&tty->secondary.proc_list);
}

//// tty 读函数。
// 从终端辅助缓冲队列中读取指定数量的字符，放到用户指定的缓冲区中。
// 参数： channel - 子设备号； buf – 用户缓冲区指针； nr - 欲读字节数。
// 返回已读字节数。
int tty_read(unsigned channel, char *buf, int nr)
{
	struct tty_struct *tty;
	char c, *b = buf;
	int minimum, time, flag = 0;
	long oldalarm;

	if (channel > 2 || nr < 0)
		return -1;
	tty = &tty_table[channel];
	oldalarm = current->alarm;
	time = 10L * tty->termios.c_cc[VTIME];
	minimum = tty->termios.c_cc[VMIN];
	if (time && !minimum) {
		minimum = 1;
		if ((flag = (!oldalarm || time + jiffies < oldalarm)))
			current->alarm = time + jiffies;
	}
	if (minimum > nr)
		minimum = nr;
	while (nr > 0) {
		if (flag && (current->signal & ALRMMASK)) {
			current->signal &= ~ALRMMASK;
			break;
		}
		if (current->signal)
			break;
		if (EMPTY(tty->secondary) || (L_CANON(tty) &&
					      !tty->secondary.data
					      && LEFT(tty->secondary) > 20)) {
			sleep_if_empty(&tty->secondary);
			continue;
		}
		do {
			GETCH(tty->secondary, c);
			if (c == EOF_CHAR(tty) || c == 10)
				tty->secondary.data--;
			if (c == EOF_CHAR(tty) && L_CANON(tty))
				return (b - buf);
			else {
				put_fs_byte(c, b++);
				if (!--nr)
					break;
			}
		} while (nr > 0 && !EMPTY(tty->secondary));
		if (time && !L_CANON(tty)) {
			if ((flag = (!oldalarm || time + jiffies < oldalarm)))
				current->alarm = time + jiffies;
			else
				current->alarm = oldalarm;
		}
// 如果 tty 终端处于规范模式，则设置最小要读取字符数 minimum 等于进程欲读字符数 nr。同
// 时把进程读取 nr 字符的超时时间值设置为极大值（不会超时）。否则说明终端处于非规范模
// 式下，若此时设置了最少读取字符数 minimum，则先临时设置进城读超时定时值为无限大，以
// 让进程先读取辅助队列中已有字符。如果读到的字符数不足 minimum 的话，后面代码会根据
// 指定的超时值 time 来设置进程的读超时值 timeout，并会等待读取其余字符。参见 328 行。
// 若此时没有设置最少读取字符数 minimum（为 0），则将其设置为进程欲读字符数 nr，并且如
// 果设置了超时定时值 time 的话，就把进程读字符超时定时值 timeout 设置为系统当前时间值
// + 指定的超时值 time，同时复位 time。 另外，如果以上设置的最少读取字符数 minimum 大
// 于进程欲读取的字符数 nr，则让 minimum=nr。即对于规范模式下的读取操作，它不受 VTIME
// 和 VMIN 对应控制字符值的约束和控制，它们仅在非规范模式（生模式）操作中起作用。
		if (L_CANON(tty)) {
			if (b - buf)
				break;
		} else if (b - buf >= minimum)
			break;
	}
	current->alarm = oldalarm;
	if (current->signal && !(b - buf))
		return -EINTR;
	return (b - buf);
}

//// tty 写函数。
// 把用户缓冲区中的字符放入 tty 写队列缓冲区中。
// 参数： channel - 子设备号； buf - 缓冲区指针； nr - 写字节数。
// 返回已写字节数。
int tty_write(unsigned channel, char *buf, int nr)
{
	static int cr_flag = 0;
	struct tty_struct *tty;
	char c, *b = buf;

	if (channel > 2 || nr < 0)
		return -1;
	tty = channel + tty_table;
	// 现在我们开始从用户缓冲区 buf 中循环取出字符并放到写队列缓冲区中。当欲写字节数大于 0，
	// 则执行以下循环操作。在循环过程中，如果此时 tty 写队列已满，则当前进程进入可中断的睡
	// 眠状态。如果当前进程有信号要处理，则退出循环体。

	while (nr > 0) {
		sleep_if_full(&tty->write_q);
		if (current->signal)
			break;
		// 当要写的字符数 nr 还大于 0 并且 tty 写队列缓冲区不满，则循环执行以下操作。首先从用户
		// 缓冲区中取 1 字节。如果终端输出模式标志集中的执行输出处理标志 OPOST 置位，则执行对
		// 字符的后处理操作。

		while (nr > 0 && !FULL(tty->write_q)) {
			c = get_fs_byte(b);
			if (O_POST(tty)) {
				// 如果该字符是回车符'\r'（ CR， 13）并且回车符转换行符标志 OCRNL 置位，则将该字符换成
				// 换行符'\n'（ NL， 10）；否则如果该字符是换行符'\n'（ NL， 10）并且换行转回车功能标志
				// ONLRET 置位的话，则将该字符换成回车符'\r'（ CR， 13）。

				if (c == '\r' && O_CRNL(tty))
					c = '\n';
				else if (c == '\n' && O_NLRET(tty))
					c = '\r';
				// 如果该字符是换行符'\n' 并且回车标志 cr_flag 没有置位，但换行转回车-换行标志 ONLCR
				// 置位的话，则将 cr_flag 标志置位，并将一回车符放入写队列中。然后继续处理下一个字符。
				// 如果小写转大写标志 OLCUC 置位的话，就将该字符转成大写字符。

				if (c == '\n' && !cr_flag && O_NLCR(tty)) {
					cr_flag = 1;
					PUTCH(13, tty->write_q);
					continue;
				}
				if (O_LCUC(tty))	// 小写转成大写字符。
					c = toupper(c);
			}

			// 接着把用户数据缓冲指针 b 前移 1 字节；欲写字节数减 1 字节；复位 cr_flag 标志，并将该
// 字节放入 tty 写队列中。
			b++;
			nr--;
			cr_flag = 0;
			PUTCH(c, tty->write_q);
		}
		// 若要求的字符全部写完，或者写队列已满，则程序退出循环。此时会调用对应 tty 写函数，
		// 把写队列缓冲区中的字符显示在控制台屏幕上，或者通过串行端口发送出去。如果当前处
		// 理的 tty 是控制台终端，那么 tty->write()调用的是 con_write()；如果 tty 是串行终端，
		// 则 tty->write()调用的是 rs_write()函数。若还有字节要写，则我们需要等待写队列中字符
		// 被取走。 所以这里调用调度程序，先去执行其他任务。

		tty->write(tty);
		if (nr > 0)
			schedule();
	}
	return b - buf;
}

/*
 * Jeh, sometimes I really like the 386.
 * This routine is called from an interrupt,
 * and there should be absolutely no problem
 * with sleeping even in an interrupt (I hope).
 * Of course, if somebody proves me wrong, I'll
 * hate intel for all time :-). We'll have to
 * be careful and see to reinstating the interrupt
 * chips before calling this, though.
 *
 * I don't think we sleep here under normal circumstances
 * anyway, which is good, as the task sleeping might be
 * totally innocent.
 */

/*
* 呵，有时我真得很喜欢 386。该子程序被从一个中断处理程序中
* 调用，并且即使在中断处理程序中睡眠也应该绝对没有问题（我
* 希望如此）。当然，如果有人证明我是错的，那么我将憎恨 intel
* 一辈子。但是我们必须小心，在调用该子程序之前需要恢复中断。
*
* 我不认为在通常环境下会处在这里睡眠，这样很好，因为任务睡眠
* 是完全任意的。
*/
//// tty 中断处理调用函数 - 字符规范模式处理。
// 参数： tty - 指定的 tty 终端号。
// 将指定 tty 终端队列缓冲区中的字符复制或转换成规范(熟)模式字符并存放在辅助队列中。
// 该函数会在串口读字符中断（ rs_io.s， 110）和键盘中断（ kerboard.S， 76）中被调用。

void do_tty_interrupt(int tty)
{
	copy_to_cooked(tty_table + tty);
}

//// 字符设备初始化函数。空，为以后扩展做准备。
void chr_dev_init(void)
{
}
