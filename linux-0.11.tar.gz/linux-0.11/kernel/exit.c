/*
 *  linux/kernel/exit.c
 *
 *  (C) 1991  Linus Torvalds
 */

#include <errno.h>		// 错误号头文件。包含系统中各种出错号。 (Linus 从 minix 中引进的)
#include <signal.h>		// 信号头文件。定义信号符号常量，信号结构以及信号操作函数原型。
#include <sys/wait.h>		// 等待调用头文件。定义系统调用 wait()和 waitpid()及相关常数符号。

#include <linux/sched.h>	// 调度程序头文件，定义了任务结构 task_struct、任务 0 数据等。
#include <linux/kernel.h>	// 内核头文件。含有一些内核常用函数的原形定义。
#include <linux/tty.h>		// tty 头文件，定义了有关 tty_io，串行通信方面的参数、常数。
#include <asm/segment.h>	// 段操作头文件。定义了有关段寄存器操作的嵌入式汇编函数。

int sys_pause(void);		// 把进程置为睡眠状态，直到收到信号（ kernel/sched.c， 164 行）。
int sys_close(int fd);		// 关闭指定文件的系统调用（ fs/open.c， 219 行）。

//// 释放进程占用的任务槽及其任务数据结构占用的内存页面。
// 参数 p 是任务数据结构指针。该函数在后面的 sys_kill() 和 sys_waitpid() 函数中被调用。
// 扫描任务指针数组表 task[] 以寻找指定的任务。如果找到，则首先清空该任务槽，然后释放
// 该任务数据结构所占用的内存页面。 最后执行调度函数并在返回时立即退出。如果在任务数组
// 表中没有找到指定任务对应的项，则内核 panic。

void release(struct task_struct *p)
{
	int i;

	// 如果给定的任务结构指针为 NULL 则退出。如果该指针指向当前进程则显示警告信息退出。

	if (!p)
		return;
	// 扫描任务结构指针数组，寻找指定的任务 p。如果找到，则置空任务指针数组中对应项，并且
	// 更新任务结构之间的关联指针，释放任务 p 数据结构占用的内存页面。最后在执行调度程序
	// 返回后退出。如果没有找到指定的任务 p，则说明内核代码出错了，则显示出错信息并死机。
	// 更新链接部分的代码会把指定任务 p 从双向链表中删除。

	for (i = 1; i < NR_TASKS; i++)
		if (task[i] == p) {
			task[i] = NULL;	/* 更新链接 */
			free_page((long)p);
			schedule();
			return;
		}
	panic("trying to release non-existent task");
}

//// 向任务 p 发送信号 sig，权限为 priv。
// 参数： sig - 信号值； p - 指定任务的指针； priv - 强制发送信号的标志。即不需要考虑进程
// 用户属性或级别而能发送信号的权利。该函数首先判断参数的正确性，然后判断条件是否满足。
// 如果满足就向指定进程发送信号 sig 并退出，否则返回未许可错误号。

static inline int send_sig(long sig, struct task_struct *p, int priv)
{
	// 如果没有权限，并且当前进程的有效用户 ID 与进程 p 的不同，并且也不是超级用户，则说明
	// 没有向 p 发送信号的权利。 suser()定义为(current->euid==0)，用于判断是否是超级用户。

	if (!p || sig < 1 || sig > 32)
		return -EINVAL;
	if (priv || (current->euid == p->euid) || suser())
		p->signal |= (1 << (sig - 1));	/* 最后，我们向进程 p 发送信号 p */
	else
		return -EPERM;
	return 0;
}

static void kill_session(void)
{
	struct task_struct **p = NR_TASKS + task;

	while (--p > &FIRST_TASK) {
		if (*p && (*p)->session == current->session)
			(*p)->signal |= 1 << (SIGHUP - 1);
	}
}

/*
 * XXX need to check permissions needed to send signals to process
 * groups, etc. etc.  kill() permissions semantics are tricky!
 */

/*
* POSIX 标准指明 kill(-1,sig)未定义。但是我所知道的可能错了。应该让它
* 象 BSD 或 SYSV 系统一样。
*/
//// 系统调用 kill()可用于向任何进程或进程组发送任何信号，而并非只是杀死进程。
// 参数 pid 是进程号； sig 是需要发送的信号。
// 如果 pid > 0，则信号被发送给进程号是 pid 的进程。
// 如果 pid = 0，那么信号就会被发送给当前进程的进程组中所有的进程。
// 如果 pid = -1，则信号 sig 就会发送给除第一个进程（初始进程） 外的所有进程。
// 如果 pid < -1，则信号 sig 将发送给进程组-pid 的所有进程。
// 如果信号 sig 为 0，则不发送信号，但仍会进行错误检查。如果成功则返回 0。
// 该函数扫描任务数组表，并根据 pid 对满足条件的进程发送指定信号 sig。若 pid 等于 0，
// 表明当前进程是进程组组长，因此需要向组内所有进程强制发送信号 sig。

int sys_kill(int pid, int sig)
{
	struct task_struct **p = NR_TASKS + task;	// p 指向任务数组最后一项。
	int err, retval = 0;

	if (!pid)
		while (--p > &FIRST_TASK) {
			if (*p && (*p)->pgrp == current->pid)
				if ((err = send_sig(sig, *p, 1)))
					retval = err;
	} else if (pid > 0)
		while (--p > &FIRST_TASK) {
			if (*p && (*p)->pid == pid)
				if ((err = send_sig(sig, *p, 0)))
					retval = err;
	} else if (pid == -1)
		while (--p > &FIRST_TASK) {
			if ((err = send_sig(sig, *p, 0)))
				retval = err;
	} else
		while (--p > &FIRST_TASK)
			if (*p && (*p)->pgrp == -pid)
				if ((err = send_sig(sig, *p, 0)))
					retval = err;
	return retval;
}

static void tell_father(int pid)
{
	int i;

	if (pid)
		for (i = 0; i < NR_TASKS; i++) {
			if (!task[i])
				continue;
			if (task[i]->pid != pid)
				continue;
			task[i]->signal |= (1 << (SIGCHLD - 1));
			return;
		}
/* if we don't find any fathers, we just release ourselves */
/* This is not really OK. Must change it to make father 1 */
	printk("BAD BAD - no father found\n\r");
	release(current);
}

// 程序退出处理函数。在下面 365 行处被系统调用 sys_exit()调用。
// 该函数将根据当前进程自身的特性对其进行处理，并把当前进程状态设置成僵死状态
// TASK_ZOMBIE，最后调用调度函数 schedule()去执行其它进程，不再返回。

int do_exit(long code)
{
	int i;

	// 首先释放当前进程代码段和数据段所占的内存页。 函数 free_page_tables() 的第 1 个参数
	// （ get_base()返回值） 指明在 CPU 线性地址空间中起始基地址，第 2 个（ get_limit()返回值）
	// 说明欲释放的字节长度值。 get_base()宏中的 current->ldt[1]给出进程代码段描述符的位置，
	// current->ldt[2]给出进程数据段描述符的位置； get_limit()中的 0x0f 是进程代码段的选择
	// 符（ 0x17 是进程数据段的选择符） 。即在取段基地址时使用该段的描述符所处地址作为参数，
	// 取段长度时使用该段的选择符作为参数（因为 CPU 有专用指令 LSL 通过选择符来取段长度） 。
	// 函数 free_page_tables()函数位于 mm/memory.c 文件的第 69 行开始处；
	// 宏 get_base()和 get_limit()位于 include/linux/sched.h 头文件的第 265 行开始处。

	free_page_tables(get_base(current->ldt[1]), get_limit(0x0f));
	free_page_tables(get_base(current->ldt[2]), get_limit(0x17));
	// 然后关闭当前进程打开着的所有文件。再对当前进程的工作目录 pwd、根目录 root、执行程序
	// 文件的 i 节点以及库文件进行同步操作，放回各个 i 节点并分别置空（释放）。 接着把当前
	// 进程的状态设置为僵死状态（ TASK_ZOMBIE） ，并设置进程退出码。

	for (i = 0; i < NR_TASKS; i++)
		if (task[i] && task[i]->father == current->pid) {
			task[i]->father = 1;
			if (task[i]->state == TASK_ZOMBIE)
				/* assumption task[1] is always init */
				(void)send_sig(SIGCHLD, task[1], 1);
		}
	for (i = 0; i < NR_OPEN; i++)
		if (current->filp[i])
			sys_close(i);
	iput(current->pwd);
	current->pwd = NULL;
	iput(current->root);
	current->root = NULL;
	iput(current->executable);
	current->executable = NULL;
	if (current->leader && current->tty >= 0)
		tty_table[current->tty].pgrp = 0;
	if (last_task_used_math == current)
		last_task_used_math = NULL;
	if (current->leader)
		kill_session();
	current->state = TASK_ZOMBIE;
	current->exit_code = code;
	tell_father(current->father);
	schedule();
	return -1;		/* just to suppress warnings */
}

// 系统调用 exit()。终止进程。
// 参数 error_code 是用户程序提供的退出状态信息，只有低字节有效。把 error_code 左移 8
// 比特是 wait() 或 waitpid()函数的要求。低字节中将用来保存 wait()的状态信息。例如，
// 如果进程处于暂停状态（ TASK_STOPPED） ，那么其低字节就等于 0x7f。参见 sys/wait.h
// 文件第 13--19 行。 wait() 或 waitpid() 利用这些宏就可以取得子进程的退出状态码或子
// 进程终止的原因（信号）。

int sys_exit(int error_code)
{
	return do_exit((error_code & 0xff) << 8);
}

// 系统调用 waitpid()。挂起当前进程， 直到 pid 指定的子进程退出（终止）或者收到要求终止
// 该进程的信号，或者是需要调用一个信号句柄（信号处理程序）。如果 pid 所指的子进程早已
// 退出（已成所谓的僵死进程），则本调用将立刻返回。子进程使用的所有资源将释放。
// 如果 pid > 0，表示等待进程号等于 pid 的子进程。
// 如果 pid = 0，表示等待进程组号等于当前进程组号的任何子进程。
// 如果 pid < -1，表示等待进程组号等于 pid 绝对值的任何子进程。
// 如果 pid = -1，表示等待任何子进程。
// 若 options = WUNTRACED，表示如果子进程是停止的，也马上返回（无须跟踪）。
// 若 options = WNOHANG，表示如果没有子进程退出或终止就马上返回。
// 如果返回状态指针 stat_addr 不为空，则就将状态信息保存到那里。
// 参数 pid 是进程号； *stat_addr 是保存状态信息位置的指针； options 是 waitpid 选项。

int sys_waitpid(pid_t pid, unsigned long *stat_addr, int options)
{
	int flag, code;		// 该标志用于后面表示所选出的子进程处于就绪或睡眠态。
	struct task_struct **p;

	// 首先验证将要存放状态信息的位置处内存空间足够。然后复位标志 flag。接着从当前进程的最
	// 年轻子进程开始扫描子进程兄弟链表。

	verify_area(stat_addr, 4);
repeat:
	flag = 0;
	for (p = &LAST_TASK; p > &FIRST_TASK; --p) {
		if (!*p || *p == current)
			continue;
		if ((*p)->father != current->pid)
			continue;
		// 如果等待的子进程号 pid>0， 并且与被扫描子进程 p 的 pid 不相等，说明它是当前进程另外的子
		// 进程。 于是跳过，接着扫描下一进程。 否则表示找到等待的子进程 pid， 于是到 390 行继续执行。

		if (pid > 0) {
			if ((*p)->pid != pid)
				continue;
			// 否则，如果指定等待进程的 pid=0，表示正在等待进程组号等于当前进程组号的任何子进程。
			// 如果此时被扫描进程 p 的进程组号与当前进程的组号不等，则跳过。 否则表示找到进程组号
			// 等于当前进程组号的某个子进程，于是到 390 行继续执行。

		} else if (!pid) {
			if ((*p)->pgrp != current->pgrp)
				continue;
			// 否则，如果指定的 pid < -1，表示正在等待进程组号等于 pid 绝对值的任何子进程。如果此时
			// 被扫描进程 p 的组号与 pid 的绝对值不等，则跳过。 否则表示找到进程组号等于 pid 绝对值的
			// 某个子进程，于是到 390 行继续执行。

		} else if (pid != -1) {
			if ((*p)->pgrp != -pid)
				continue;
		}
		// 如果前 3 个对 pid 的判断都不符合，则表示当前进程正等待其任何子进程（此时 pid = -1）。
		//
		// 此时所选择到的进程 p 或者是其进程号等于指定 pid，或者是当前进程组中的任何子进程，
		// 或者是进程号等于指定 pid 绝对值的子进程，或者是任何子进程（此时指定的 pid = -1）。
		// 接下来根据这个子进程 p 所处的状态来处理。
		//
		// 当子进程 p 处于停止状态时，如果此时参数选项 options 中 WUNTRACED 标志没有置位，表示
		// 程序无须立刻返回，或者子进程此时的退出码等于 0，于是继续扫描处理其他子进程。 如果
		// WUNTRACED 置位且子进程退出码不为 0，则把退出码移入高字节， ‘ 或’ 上状态 0x7f 后放入
		// *stat_addr，在复位子进程退出码后就立刻返回子进程号 pid。这里 0x7f 表示的返回状态使
		// WIFSTOPPED()宏为真。参见 include/sys/wait.h， 14 行。

		switch ((*p)->state) {
		case TASK_STOPPED:
			if (!(options & WUNTRACED))
				continue;
			put_fs_long(0x7f, stat_addr);
			return (*p)->pid;
			// 如果子进程 p 处于僵死状态，则首先把它在用户态和内核态运行的时间分别累计到当前进程
			// （父进程）中，然后取出子进程的 pid 和退出码，把退出码放入返回状态位置 stat_addr 处
			// 并释放该子进程。最后返回子进程的退出码和 pid。 若定义了调试进程树符号，则调用进程
			// 树检测显示函数。

		case TASK_ZOMBIE:
			current->cutime += (*p)->utime;
			current->cstime += (*p)->stime;
			flag = (*p)->pid;
			code = (*p)->exit_code;
			release(*p);
			put_fs_long(code, stat_addr);
			return flag;
			// 如果这个子进程 p 的状态既不是停止也不是僵死，那么就置 flag = 1。表示找到过一个符合
			// 要求的子进程，但是它处于运行态或睡眠态。

		default:
			flag = 1;
			continue;
		}
	}
	// 在上面对任务数组扫描结束后，如果 flag 被置位，说明有符合等待要求的子进程并没有处
	// 于退出或僵死状态。此时如果已设置 WNOHANG 选项（表示若没有子进程处于退出或终止态就
	// 立刻返回），就立刻返回 0 并退出。 否则把当前进程置为可中断等待状态， 保留并修改当
	// 前进程信号阻塞位图，允许其接收到 SIGCHLD 信号。然后执行调度程序。当系统又开始执行
	// 本进程时，如果本进程收到除 SIGCHLD 以外的其他未屏蔽信号，则以退出码“重新启动系统
	// 调用”返回。否则跳转到函数开始处 repeat 标号处重复处理。

	if (flag) {
		if (options & WNOHANG)
			return 0;
		current->state = TASK_INTERRUPTIBLE;
		schedule();
		if (!(current->signal &= ~(1 << (SIGCHLD - 1))))
			goto repeat;
		else
			return -EINTR;
	}
	return -ECHILD;		// 若 flag = 0，表示没有找到符合要求的子进程，则返回出错码（子进程不存在）。
}
