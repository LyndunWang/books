/*
 *  linux/kernel/sys.c
 *
 *  (C) 1991  Linus Torvalds
 */

#include <errno.h>		// 错误号头文件。包含系统中各种出错号。

#include <linux/sched.h>	// 调度程序头文件。定义了任务结构 task_struct、任务 0 的数据，
// 还有一些有关描述符参数设置和获取的嵌入式汇编函数宏语句。
#include <linux/tty.h>		// tty 头文件，定义了有关 tty_io，串行通信方面的参数、常数。
#include <linux/kernel.h>	// 内核头文件。含有一些内核常用函数的原形定义。
#include <asm/segment.h>	// 段操作头文件。定义了有关段寄存器操作的嵌入式汇编函数。
#include <sys/times.h>		// 定义了进程中运行时间的结构 tms 以及 times()函数原型。
#include <sys/utsname.h>	// 系统名称结构头文件。

// 返回日期和时间（ ftime – Fetch time） 。
// 以下返回值是-ENOSYS 的系统调用函数均表示在本版本内核中还未实现。

int sys_ftime()
{
	return -ENOSYS;
}

int sys_break()
{
	return -ENOSYS;
}

// 用于当前进程对子进程进行调试(debugging)。

int sys_ptrace()
{
	return -ENOSYS;
}

// 改变并打印终端行设置。

int sys_stty()
{
	return -ENOSYS;
}

// 取终端行设置信息。

int sys_gtty()
{
	return -ENOSYS;
}

// 修改文件名。

int sys_rename()
{
	return -ENOSYS;
}

int sys_prof()
{
	return -ENOSYS;
}

/*
* 以下是 BSD 形式的实现，没有考虑保存的 gid（ saved gid 或 sgid），除了当你
* 设置了有效的 gid（ effective gid 或 egid）时，保存的 gid 也会被设置。 这使
* 得一个使用 setgid 的程序可以完全放弃其特权。当你在对一个程序进行安全审
* 计时，这通常是一种很好的处理方法。
*
* 最基本的考虑是一个使用 setregid()的程序将会与 BSD 系统 100%的兼容。而一
* 个使用 setgid()和保存的 gid 的程序将会与 POSIX 100%的兼容。
*/
// 设置当前任务的真实以及/或者有效组 ID（ gid） 。如果任务没有超级用户特权，那么只能互
// 换其真实组 ID 和有效组 ID。如果任务具有超级用户特权，就能任意设置有效的和真实的组
// ID， 保留的 gid（ sgid） 被设置成有效 gid（ egid） 。 真实组 ID 是指进程当前的 gid。

int sys_setregid(int rgid, int egid)
{
	if (rgid > 0) {
		if ((current->gid == rgid) || suser())
			current->gid = rgid;
		else
			return (-EPERM);
	}
	if (egid > 0) {
		if ((current->gid == egid) ||
		    (current->egid == egid) ||
		    (current->sgid == egid) || suser())
			current->egid = egid;
		else
			return (-EPERM);
	}
	return 0;
}

/*
* setgid()的实现与具有 SAVED_IDS 的 SYSV 的实现方法相似。
*/
// 设置进程组号(gid)。如果任务没有超级用户特权，它可以使用 setgid() 将其有效 gid
// （ effective gid） 设置为成其保留 gid(saved gid)或其真实 gid(real gid)。如果任务
// 有超级用户特权，则真实 gid、有效 gid 和保留 gid 都被设置成参数指定的 gid。

int sys_setgid(int gid)
{
	return (sys_setregid(gid, gid));
}

// 打开或关闭进程计帐功能。
int sys_acct()
{
	return -ENOSYS;
}

// 映射任意物理内存到进程的虚拟地址空间。

int sys_phys()
{
	return -ENOSYS;
}

int sys_lock()
{
	return -ENOSYS;
}

int sys_mpx()
{
	return -ENOSYS;
}

int sys_ulimit()
{
	return -ENOSYS;
}

// 返回从 1970 年 1 月 1 日 00:00:00 GMT 开始计时的时间值（秒）。
// 如果指针 tloc 不为 null， 则返回的时间值也存储在 tloc 所指处。
// 由于参数所指位置在用户空间，因此需要使用函数 put_fs_long() 把时间值存储到用户空间。
// 在内核中运行时，段寄存器 fs 被默认地指向当前用户数据空间。因此该函数就可利用 fs 段寄
// 存器来访问用户空间中的值。

int sys_time(long *tloc)
{
	int i;

	i = CURRENT_TIME;
	if (tloc) {
		verify_area(tloc, 4);	// 验证内存容量是否够（这里是 4 字节）。
		put_fs_long(i, (unsigned long *)tloc);	// 放入用户数据段 tloc 处。
	}
	return i;
}

/*
 * Unprivileged users may change the real user id to the effective uid
 * or vice versa.
 */

/*
* 无特权的用户可以将真实 uid（ real uid）改成有效 uid（ effective uid），
* 反之也然。（ BSD 形式的实现）
*
* 当你设置有效的 uid 时，它同时也设置了保存的 uid。 这使得一个使用 setuid
* 的程序可以完全放弃其特权。当你在对一个程序进行安全审计时，这通常是一种
* 很好的处理方法。
* 最基本的考虑是一个使用 setreuid()的程序将会与 BSD 系统 100%的兼容。而一
* 个使用 setuid()和保存的 gid 的程序将会与 POSIX 100%的兼容。
*/
// 设置任务的真实以及/或者有效用户 ID（ uid） 。如果任务没有超级用户特权，那么只能互换
// 其真实 uid(ruid)和有效 uid(euid)。如果任务具有超级用户特权，就能任意设置有效的和真
// 实的 uid。保存的 uid（ suid） 被设置成与 euid 同值。

int sys_setreuid(int ruid, int euid)
{
	int old_ruid = current->uid;

	if (ruid > 0) {
		if ((current->euid == ruid) || (old_ruid == ruid) || suser())
			current->uid = ruid;
		else
			return (-EPERM);
	}
	if (euid > 0) {
		if ((old_ruid == euid) || (current->euid == euid) || suser())
			current->euid = euid;
		else {
			current->uid = old_ruid;
			return (-EPERM);
		}
	}
	return 0;
}

/*
* setuid()的实现与具有 SAVED_IDS 的 SYSV 的实现方法相似。
*
* 请注意使用 SAVED_ID 的 setuid()在某些方面是不完善的。例如，一个使用
* setuid 的超级用户程序 sendmail 就做不到把其 uid 设置成一个普通用户的
* uid，然后再交换回来。 因为如果你是一个超级用户， setuid() 也同时会
* 设置保存的 uid。如果你不喜欢这样的做法的话，就责怪 POSIX 组委会以及
* /或者 USG 中的聪明人吧。不过请注意 BSD 形式的 setreuid()实现能够允许
* 一个超级用户程序临时放弃特权，并且能通过交换实际的和有效的 uid 而
* 再次获得特权。
*/
// 设置任务用户 ID（ uid）。如果任务没有超级用户特权，它可以使用 setuid()将其有效的
// uid（ effective uid） 设置成其保存的 uid（ saved uid）或其实际的 uid（ real uid）。
// 如果任务有超级用户特权，则实际的 uid、有效的 uid 和保存的 uid 都会被设置成参数指
// 定的 uid。

int sys_setuid(int uid)
{
	return (sys_setreuid(uid, uid));
}

// 设置系统开机时间。参数 tptr 是从 1970 年 1 月 1 日 00:00:00 GMT 开始计时的时间值（秒）。
// 调用进程必须具有超级用户权限。其中 HZ=100，是内核系统运行频率。
// 由于参数是一个指针，而其所指位置在用户空间，因此需要使用函数 get_fs_long()来访问该
// 值。在进入内核中运行时，段寄存器 fs 被默认地指向当前用户数据空间。因此该函数就可利
// 用 fs 来访问用户空间中的值。
// 函数参数提供的当前时间值减去系统已经运行的时间秒值（ jiffies/HZ） 即是开机时间秒值。

int sys_stime(long *tptr)
{
	if (!suser())		// 如果不是超级用户则出错返回（许可）。
		return -EPERM;
	startup_time = get_fs_long((unsigned long *)tptr) - jiffies / HZ;
	return 0;
}

// 获取当前任务运行时间统计值。
// 在 tbuf 所指用户数据空间处返回 tms 结构的任务运行时间统计值。 tms 结构中包括进程用户
// 运行时间、内核（系统）时间、子进程用户运行时间、子进程系统运行时间。函数返回值是
// 系统运行到当前的嘀嗒数。

int sys_times(struct tms *tbuf)
{
	if (tbuf) {
		verify_area(tbuf, sizeof *tbuf);
		put_fs_long(current->utime, (unsigned long *)&tbuf->tms_utime);
		put_fs_long(current->stime, (unsigned long *)&tbuf->tms_stime);
		put_fs_long(current->cutime,
			    (unsigned long *)&tbuf->tms_cutime);
		put_fs_long(current->cstime,
			    (unsigned long *)&tbuf->tms_cstime);
	}
	return jiffies;
}

// 设置程序在内存中的末端位置。
// 当参数 end_data_seg 数值合理，并且系统确实有足够的内存，而且进程没有超越其最大数据
// 段大小时，该函数设置数据段末尾为 end_data_seg 指定的值。该值必须大于代码结尾并且要
// 小于堆栈结尾 16KB。返回值是数据段的新结尾值（如果返回值与要求值不同，则表明有错误
// 发生）。该函数并不被用户直接调用，而由 libc 库函数进行包装，并且返回值也不一样。

int sys_brk(unsigned long end_data_seg)
{
	// 如果参数值大于代码结尾，并且小于（堆栈 - 16KB），则设置新数据段结尾值。

	if (end_data_seg >= current->end_code &&
	    end_data_seg < current->start_stack - 16384)
		current->brk = end_data_seg;
	return current->brk;	// 返回进程当前的数据段结尾值。
}

/*
 * This needs some heave checking ...
 * I just haven't get the stomach for it. I also don't fully
 * understand sessions/pgrp etc. Let somebody who does explain it.
 */

/*
* 下面代码需要某些严格的检查…
* 我只是没有胃口来做这些。我也不完全明白 sessions/pgrp 等的含义。还是让
* 了解它们的人来做吧。
*
* OK，我想我已经正确地实现了保护语义...。总之，这其实只对多用户系统是
* 重要的，以确定一个用户不能向其他用户的进程发送信号。 -TYT 12/12/91
*/
// 设置指定进程 pid 的进程组号为 pgid。
// 参数 pid 是指定进程的进程号。如果它为 0，则让 pid 等于当前进程的进程号。参数 pgid
// 是指定的进程组号。如果它为 0，则让它等于进程 pid 的进程组号。如果该函数用于将进程
// 从一个进程组移到另一个进程组，则这两个进程组必须属于同一个会话(session)。在这种
// 情况下，参数 pgid 指定了要加入的现有进程组 ID，此时该组的会话 ID 必须与将要加入进
// 程的相同(263 行)。

int sys_setpgid(int pid, int pgid)
{
	int i;

	// 如果参数 pid 为 0，则 pid 取值为当前进程的进程号 pid。如果参数 pgid 为 0，则 pgid 也
	// 取值为当前进程的 pid。 [?? 这里与 POSIX 标准的描述有出入 ]。若 pgid 小于 0，则返回
	// 无效错误码。

	if (!pid)
		pid = current->pid;
	if (!pgid)
		pgid = current->pid;
	// 扫描任务数组，查找指定进程号 pid 的任务。如果找到了进程号是 pid 的进程，并且该进程
	// 的父进程就是当前进程或者该进程就是当前进程，那么若该任务已经是会话首领，则出错返回。
	// 若该任务的会话号（ session） 与当前进程的不同，或者指定的进程组号 pgid 与 pid 不同并且
	// pgid 进程组所属会话号与当前进程所属会话号不同，则也出错返回。 否则把查找到的进程的
	// pgrp 设置为 pgid，并返回 0。若没有找到指定 pid 的进程，则返回进程不存在出错码。

	for (i = 0; i < NR_TASKS; i++)
		if (task[i] && task[i]->pid == pid) {
			if (task[i]->leader)
				return -EPERM;
			if (task[i]->session != current->session)
				return -EPERM;
			task[i]->pgrp = pgid;
			return 0;
		}
	return -ESRCH;
}

// 返回当前进程的进程组号。与 getpgid(0)等同。

int sys_getpgrp(void)
{
	return current->pgrp;
}

// 创建一个会话(session)（即设置其 leader=1） ，并且设置其会话号=其组号=其进程号。
// 如果当前进程已是会话首领并且不是超级用户，则出错返回。否则设置当前进程为新会话
// 首领（ leader = 1） ，并且设置当前进程会话号 session 和组号 pgrp 都等于进程号 pid，
// 而且设置当前进程没有控制终端。最后系统调用返回会话号。

int sys_setsid(void)
{
	if (current->leader && !suser())
		return -EPERM;
	current->leader = 1;
	current->session = current->pgrp = current->pid;
	current->tty = -1;	// 表示当前进程没有控制终端。
	return current->pgrp;
}

// 获取系统名称等信息。

int sys_uname(struct utsname *name)
{
	static struct utsname thisname = {
		"linux .0", "nodename", "release ", "version ", "machine "
	};
	int i;

	if (!name)
		return -ERROR;
	verify_area(name, sizeof *name);
	for (i = 0; i < sizeof *name; i++)
		put_fs_byte(((char *)&thisname)[i], i + (char *)name);
	return 0;
}

// 设置当前进程创建文件属性屏蔽码为 mask & 0777， 并返回原屏蔽码。

int sys_umask(int mask)
{
	int old = current->umask;

	current->umask = mask & 0777;
	return (old);
}
